<?php

class CRD_Exception_FileNotFound extends CRD_Exception {}
