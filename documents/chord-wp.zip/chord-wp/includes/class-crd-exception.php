<?php

class CRD_Exception extends Exception {}
